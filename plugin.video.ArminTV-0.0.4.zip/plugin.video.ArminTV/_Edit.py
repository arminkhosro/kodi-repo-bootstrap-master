import xbmcaddon

MainBase = 'http://pastebin.com/raw/L1ap79Lh'
addon = xbmcaddon.Addon('plugin.video.ArminTV')